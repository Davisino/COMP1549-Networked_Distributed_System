
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * A simple Swing-based client for the chat server. Graphically it is a frame with a text
 * field for entering messages and a textarea to see the whole dialog.
 *
 * The client follows the following Chat Protocol. When the server sends "SUBMITNAME" the
 * client replies with the desired screen name. The server will keep sending "SUBMITNAME"
 * requests as long as the client submits screen names that are already in use. When the
 * server sends a line beginning with "NAMEACCEPTED" the client is now allowed to start
 * sending the server arbitrary strings to be broadcast to all chatters connected to the
 * server. When the server sends a line beginning with "MESSAGE" then all characters
 * following this string should be displayed in its message area.
 */
public class Client {
    String serverAddress;
    Scanner in;
    PrintWriter out;
    JFrame frame = new JFrame("Chatter");
    JTextField textField = new JTextField(50);
    JTextArea messageArea = new JTextArea(16, 50);
    Map<Integer, User> users = new HashMap<Integer, User>();


    /**
     * Constructs the client by laying out the GUI and registering a listener with the
     * textfield so that pressing Return in the listener sends the textfield contents
     * to the server. Note however that the textfield is initially NOT editable, and
     * only becomes editable AFTER the client receives the NAMEACCEPTED message from
     * the server.
     */
    public Client(String serverAddress) {
        this.serverAddress = serverAddress;

        textField.setEditable(false);
        messageArea.setEditable(false);
        frame.getContentPane().add(textField, BorderLayout.SOUTH);
        frame.getContentPane().add(new JScrollPane(messageArea), BorderLayout.CENTER);
        frame.pack();

        // Send on enter then clear to prepare for next message
        textField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //the stream write here sends the message directly to the server with no pre-processing by the client.
                out.println(textField.getText());
                textField.setText("");
            }
        });
    }

    private String getName() {
        return JOptionPane.showInputDialog(
            frame,
            "Choose a screen name:",
            "Screen name selection",
            JOptionPane.PLAIN_MESSAGE
        );
    }

    //All stream operations peformned here are responsible for incoming server events.
    private void run() throws IOException {
        Socket socket = null;
        try {
            socket = new Socket(serverAddress, 59001);
            in = new Scanner(socket.getInputStream());
            out = new PrintWriter(socket.getOutputStream(), true);

            while (in.hasNextLine()) {
                String line = in.nextLine();
                if (line.startsWith("SUBMITNAME")) {
                	// Handle SUBMITNAME; Prompts the user to type username
                    out.println(getName());
                } else if (line.startsWith("NAMEACCEPTED")) {
                	// Handle NAMEACCEPTED; Set chatbox title to username and make chat editable
                    this.frame.setTitle("Chatter - " + line.substring(13));
                    textField.setEditable(true);
                } else if (line.startsWith("MESSAGE")) {
                	// Handle MESSAGE; Display message to chatbox
                    messageArea.append(line.substring(8) + "\n");
                } else if (line.startsWith("PRIVATE")) {
                	// Handle PRIVATE; Display message to chatbox to specific client (handled by server);
                    messageArea.append(line.substring(8) + "\n");
                }
                else if (line.startsWith("USERS"))
                {
                    users = new HashMap<Integer, User>();

                    String[] data = line.substring("USERS".length() + 1).split(","); //+1 to remove the space
                    for (int i = 0; i < data.length; i++)
                    {
                        String[] parts = data[i].split(":");
                        String ipAddress = parts[2];
                        if (ipAddress.startsWith("/"))
                            ipAddress = ipAddress.substring(1);
                        User user = new User(Integer.parseInt(parts[0]), parts[1], ipAddress);
                        users.put(user.getId(), user);
                    }
                }
                else if (line.startsWith("USER"))
                {
                    //Used for a status update about a connection.
                    String[] parts = line.substring("USER".length() + 1).split(":");
                    Integer id = Integer.parseInt(parts[0]);
                    String name = parts[1];
                    String ipAddress = parts[2];
                    if (ipAddress.startsWith("/"))
                        ipAddress = ipAddress.substring(1);
                    boolean status = Boolean.parseBoolean(parts[4]); //Skip 3 as port is sent along with the IP address.

                    boolean exists = users.containsKey(id);

                    if (status && !exists) //If they have connected add the user.
                    {
                        User user = new User(id, name, ipAddress);
                        users.put(user.getId(), user);

                        messageArea.append(user.getName() + " has connected.\n");
                    }
                    else if (!status && exists) //They have disconnected, remove them.
                    {
                        users.remove(id);

                        messageArea.append(name + " has disconnected.\n");
                    }
                }
            }
        } finally {
            if (socket != null)
                socket.close();
            frame.setVisible(false);
            frame.dispose();
        }
    }

    public static void main(String[] args) throws Exception {
    	// creates a new client with the ip address from the arguments 
    
        // if (args.length != 1) {
        //     System.err.println("Pass the server IP as the sole command line argument");
        //     return;
        // }
        //String host = "localhost";
        Client client = new Client("localhost");
        client.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        client.frame.setVisible(true);
        client.run();
    }
}
